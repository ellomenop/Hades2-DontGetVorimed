# Mod name

Hades II mod allowing to do some super duper thing.

## Features

- Wow.
- Much cool.
  - Very doge.

## Install

- Do this.
- Do that.
  - Nope, not that.
