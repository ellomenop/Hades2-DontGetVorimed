return {
  version = 0;
  enabled = true;
  message = 'Hello World!';
}